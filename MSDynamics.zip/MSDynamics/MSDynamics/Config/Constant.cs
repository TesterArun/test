﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MSDynamics.Config
{
    public class Constant
    {
      public static readonly String URL = "https://www.store.demoqa.com";

      public static readonly String Username = "testuser_1";

      public static readonly String Password = "Test@123";

      public static readonly String Path_TestData = "C:\\Users\\mogandhi\\Documents\\MSDynamics\\MSDynamics\\Data\\";

      public static readonly String File_TestData = "TestData.xlsx";

    }
}
