﻿using java.io;
using Magnum.Extensions;
using Magnum.FileSystem;
using NPOI.HPSF;
using NPOI.Util;
using NPOI.XSSF.UserModel;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using File = Magnum.FileSystem.File;
using MSDynamics.Config;


namespace MSDynamics.Utility
{
    public class ExcelUtility
    {
        private static XSSFSheet ExcelWSheet;

        private static XSSFWorkbook ExcelWBook;

        private static XSSFCell Cell;

        private static XSSFRow Row;

        //This method is to set the File path and to open the Excel file, Pass Excel Path and Sheetname as Arguments to this method

        public static void setExcelFile(String Path, String SheetName)
        {
            FileStream ExcelFile;


            try
            {

                // Open the Excel file
                ExcelFile = new FileStream(Path, FileMode.Open);

                // Access the required test data sheet

                ExcelWBook = new XSSFWorkbook(ExcelFile);

                ExcelWSheet = (XSSFSheet)ExcelWBook.GetSheet(SheetName);

            } catch (Exception e){

						throw (e);

					}

}

//This method is to read the test data from the Excel cell, in this we are passing parameters as Row num and Col num

public static String getCellData(int RowNum, int ColNum)
{

       			try{

                Cell = (XSSFCell)ExcelWSheet.GetRow(RowNum).GetCell(ColNum);

        String CellData = Cell.GetRawValue();

        return CellData;

    }catch (Exception e){

        return "";

    }

}

//This method is to write in the Excel cell, Row num and Col num are the parameters

public static void setCellData(String Result, int RowNum, int ColNum)
{

       			try{

        Row = (XSSFRow)ExcelWSheet.GetRow(RowNum);
        Cell = (XSSFCell)Row.GetCell(ColNum);


        if (Cell == null)
        {

            Cell = (XSSFCell)Row.CreateCell(ColNum);

            Cell.SetCellValue(Result);

        }
        else
        {

            Cell.SetCellValue(Result);

        }

                // Constant variables Test Data path and Test Data file name

        FileOutputStream fileOut = new FileOutputStream(Constant.Path_TestData);
                ExcelWBook.Write(fileOut);
        fileOut.flush();

        fileOut.close();

    }catch(Exception e){

        throw (e);

    }

}

	}
    }
}
