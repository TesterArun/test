﻿using MSDynamics.Base;
using MSDynamics.Utility;
using OpenQA.Selenium;
using OpenQA.Selenium.Support;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MSDynamics.Pages
{
    public class LoginPage:BaseClass
    {

        //constructor to init the pageFactoryElements
        public LoginPage(IWebDriver driver)
        {
            this.driver = driver;
            PageFactory.InitElements(driver, this);           
        }

        //PageObject Repository
        [FindsBy(How = How.XPath, Using = "//input[@id='email']")]
        public IWebElement UserName { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@id='pass']")]
        public IWebElement Password { get; set; }

        //Methods
        public void EnterUserName()
        {
            UserName.SendKeys("arundarll007@gmail.com");
        }
        public void EnterPassword()
        {
            Password.SendKeys("Testing");
        }

    }   
    
}
