﻿using MSDynamics.Base;
using MSDynamics.Pages;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MSDynamics.Tests
{
    [TestFixture]
    public class LoginTest: BaseClass
    {


        [Test]
        public void Login()
        {
          var loginPage = new LoginPage(driver);
            loginPage.EnterUserName();
            loginPage.EnterPassword();
        }

     



    }
}