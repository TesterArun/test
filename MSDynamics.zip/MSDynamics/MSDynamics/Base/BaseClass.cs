﻿using MSDynamics.Utility;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MSDynamics.Base
{
    public class BaseClass
    {
        BrowserUtility broweserFactory = new BrowserUtility();
        public IWebDriver driver;



        [SetUp]
        public void launchApplication()
        {
            driver = new ChromeDriver();
            driver.Manage().Window.Maximize();
            driver.Url = "https://www.facebook.com/";
            driver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(50);
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(50);

        }
        [TearDown]
        public void closeApplication()
        {
            driver.Close();        }

    }
}
